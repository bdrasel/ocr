from flask import Flask, request, jsonify
import easyocr
import os
import cv2
import numpy as np
from rapidfuzz import process
import logging

app = Flask(__name__)
logging.basicConfig(level=logging.DEBUG)

def is_image_quality_low(image_path):
    """
    Check the quality of the image.
    Criteria: Low brightness or low sharpness.
    """
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if image is None:
        return "Failed to load image."

    # Check brightness
    brightness = np.mean(image)
    if brightness < 50:
        return "Image is too dark."

    # Check sharpness
    laplacian_var = cv2.Laplacian(image, cv2.CV_64F).var()
    if laplacian_var < 100:
        return "Image is too blurry."

    return None


@app.route('/image_to_text', methods=['POST'])
def nid_ocr():
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file part in the request'}), 400

        image_file = request.files['file']
        temp_path = os.path.join('uploads', image_file.filename)
        os.makedirs(os.path.dirname(temp_path), exist_ok=True)
        image_file.save(temp_path)

        quality_issue = is_image_quality_low(temp_path)
        if quality_issue:
            os.remove(temp_path)
            return jsonify({'error': quality_issue}), 400

        try:
            reader = easyocr.Reader(['en', 'bn'], gpu=True)
        except Exception as gpu_error:
            logging.warning("GPU not available, falling back to CPU.")
            reader = easyocr.Reader(['en', 'bn'], gpu=False)

        result = reader.readtext(temp_path)

        raw_text = [detection[1] for detection in result]
        os.remove(temp_path)

        corrected_data = parse_nid_data(raw_text)
        return jsonify(corrected_data), 200

    except Exception as e:
        logging.error(f"Error processing image: {e}")
        return jsonify({'error': str(e)}), 400


def parse_nid_data(raw_text):
    """
    Parse the text extracted from an ID and handle both temporary and permanent ID formats.
    """
    correct_fields = {
        "নাম": "Name_bn",
        "Name": "Name_en",
        "পিতা": "Father's Name",
        "মাতা": "Mother's Name",
        "Date of Birth": "Date of Birth",
        "NID No": "NID Number",
        "ID NO": "NID Number",
    }

    corrections = {
        "মাম": "নাম",
        "মাঢা": "মাতা",
        "Dare of Birth": "Date of Birth",
        "ID NO": "NID No",
    }

    # Initialize dictionary to store corrected data
    data = {}
    temp_key = None  # Temporarily hold the key while processing

    # Correct OCR mistakes using the corrections dictionary
    raw_text = [corrections.get(text, text) for text in raw_text]

    # Process raw text and extract fields
    for i, text in enumerate(raw_text):
        logging.debug(f'raw_text[{i}]: {text}')
        
        # Match fields based on exact matches
        if text in correct_fields:
            temp_key = correct_fields[text]
        elif temp_key:
            # Assign the value to the identified key
            if temp_key not in data:
                data[temp_key] = text
            temp_key = None

    return data


if __name__ == '__main__':
    app.run(debug=True)
